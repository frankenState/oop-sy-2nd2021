/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdiscussion;
import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author frank lou
 */
public class CRUD {

    public Connection getCon() {
        return con;
    }

    private Connection con;
    
    public CRUD(String host, String username, String password){
        try {
            
            this.con = DriverManager.getConnection(host, username, password);
            
        } catch (SQLException e){
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    public boolean insertData(String query, Object[] data){
        boolean success = false;
        
        try {
            PreparedStatement stmt = this.con.prepareStatement(query);
            
            for (int i = 0; i < data.length; i++){
                stmt.setObject(i + 1, data[i]);
            }
            
           stmt.execute();
            
           success = true;
            
        } catch(SQLException e ){
            System.out.println("ERROR: " + e.getMessage());
        }
        
        return success;
    }
    
    public boolean deleteData(String query, String id){
        boolean success = false;
        
        try {
            PreparedStatement stmt = this.con.prepareStatement(query);
            stmt.setString(1, id);
            
            stmt.execute();
            
            success = true;
            
        } catch (SQLException e){   
            System.out.println("Error: " + e.getMessage());
        }
        
        return success;
    }
    
    public ArrayList getData(){
        ArrayList list = new ArrayList();
        
        try {
            
            Statement stmt = this.con.createStatement();
            
            ResultSet rs = stmt.executeQuery("SELECT * FROM students");
            
            while (rs.next()){
                int id = rs.getInt("id");
                String firstname = rs.getString("first_name");
                String lastname = rs.getString("last_name");
                int midterm = rs.getInt("midterm");
                int final_grade = rs.getInt("final");
                
                Object[] row = { id, firstname, lastname, midterm, final_grade };
                list.add(row);
            }
            
        } catch (SQLException e){
            System.out.println("Error: " + e.getMessage());
        }
        
        
        return list;
    }
    
    
    public static void main(String[] args) {
        try {
            CRUD db = new CRUD("jdbc:mysql://localhost/is122_discuss", "root", "");
            
            Statement stmt = db.getCon().createStatement();
            
            ResultSet rs = stmt.executeQuery("SELECT * FROM students");
            
            while (rs.next()){
                
                int id = rs.getInt("id");
                String firstname = rs.getString("first_name");
                String lastname = rs.getString("last_name");
                int midterm = rs.getInt("midterm");
                int final_grade = rs.getInt("final");
                
                System.out.printf(
                    "%-5s %-5s %-5s %-5s %-5s\n",
                    id, firstname, lastname, midterm, final_grade
                );
            }
            
        } catch (SQLException e){
            System.out.println("ERROR: " + e.getMessage());
        }
    }
    
}
